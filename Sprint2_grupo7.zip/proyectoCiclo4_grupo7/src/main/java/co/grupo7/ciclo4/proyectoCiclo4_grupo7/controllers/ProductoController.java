package co.grupo7.ciclo4.proyectoCiclo4_grupo7.controllers;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import co.grupo7.ciclo4.proyectoCiclo4_grupo7.models.ProductoModel;
import co.grupo7.ciclo4.proyectoCiclo4_grupo7.services.ProductoService;

@RestController
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.DELETE})
@RequestMapping("/producto")
public class ProductoController {
    
    @Autowired
    ProductoService productoService;

    @GetMapping()
    public ArrayList<ProductoModel> obtenerproductos(){
        return  productoService.obtenerProductos();
    }

    @PostMapping()
    public ProductoModel guardarProducto(@RequestBody ProductoModel producto){
        return productoService.guardarProducto(producto);
    }

    @DeleteMapping(path = "{id}")
    public String eliminarProductoPorId(@PathVariable("id") String id){

        if(this.productoService.eliminarProductoPorID(id)){

            return "Se eliminó el producto con referencia: " + id;

        }
        else{

            return "No existe el producto con referencia: " + id;

        }

    }

    @GetMapping(path = "{id}")
    public Optional<ProductoModel> obtenerProductoPorId(@PathVariable("id") String id){
        
        return productoService.obtenerProductoPorID(id);

    }

}
